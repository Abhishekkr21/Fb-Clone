# Facebook-clone-Web-Application
A full featured FACEBOOK CLONE web application written in Python-Flask that I developed with python-flask, html, css and javascript.


![alt text](https://upload.wikimedia.org/wikipedia/commons/thumb/3/3c/Flask_logo.svg/1200px-Flask_logo.svg.png)

![alt text](https://blog.theodo.com/static/daf0a6158eac76e700891058b02de9cc/a79d3/facebook2.png)

A full-featured facebook-clone web application with the backend written in Python-Flask , frontend written with html,css, bootstrap and javascript. 

Features: 1. Users can Create Accounts
          2. Users can make blog tasks
          3. Users can follow other users
          4. Users can edit profile details 
          5. Users can recover forgotten password with their email
          6. Users can send private messages to other users
